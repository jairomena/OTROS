insert into authors(first_name,  last_name)
            values ('Marianela', 'Lopez') ;

insert into authors(first_name,  last_name)
            values ('David',     'Silva') ;

insert into authors(first_name,  last_name)
            values ('Luis',      'Davila') ;

insert into authors(first_name,  last_name)
            values ('Jonathan',  'Mendoza');

insert into books(isbn,    title,   author_id, price)
          values ('11-11', 'title1',1,         20);

insert into books(isbn,    title,    author_id, price)
          values ('22-22', 'title2', 2,         20);

insert into books(isbn,    title,    author_id, price)
          values ('33-33', 'title3', 3,         20);

insert into books(isbn,    title,    author_id, price)
          values ('44-44', 'title4', 4,         20);

