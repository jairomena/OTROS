package com.distribuida.main;

public class BooksMain {

    public static void main(String[] args) {
        io.helidon.microprofile.cdi.Main.main(args);
    }

}
